#include "stdafx.h"
#include "Mensagem.h"


Mensagem::Mensagem()
{
}


Mensagem::~Mensagem()
{
}
