#include "stdafx.h"
#include "Pair.h"


Pair::Pair()
{
}


Pair::~Pair()
{
}
