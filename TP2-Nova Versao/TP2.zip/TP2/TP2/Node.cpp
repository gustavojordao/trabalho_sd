#include "stdafx.h"
#include "Node.h"


Node::Node()
{
	indice = 0;

}


Node::~Node()
{
}
