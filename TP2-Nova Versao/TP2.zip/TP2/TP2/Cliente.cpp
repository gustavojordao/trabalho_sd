#include "stdafx.h"
#include "Cliente.h"


Cliente::Cliente()
{
}


Cliente::~Cliente()
{
}
